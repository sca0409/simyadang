// 심야당 커뮤니티 고급 구조 (관리자/유저 구분, 공지 고정, 투표 기능 포함)
// 기술 스택: React + TailwindCSS + Firebase (Auth + Firestore + Storage)

import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { UploadCloud } from "lucide-react";
import { motion } from "framer-motion";

// 모의 사용자 정보 (실제 Firebase Auth 연동 필요)
const currentUser = {
  uid: "user123",
  nickname: "익명123",
  isAdmin: true // 관리자는 true, 일반 유저는 false
};

export default function Home() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [file, setFile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [voteCount, setVoteCount] = useState(0);

  const handleUpload = async () => {
    const newPost = {
      id: Date.now(),
      title,
      content,
      fileName: file?.name || null,
      isNotice: currentUser.isAdmin && title.startsWith("[공지]"),
      votes: 0
    };
    setPosts([newPost, ...posts]);
    alert("게시물 업로드 완료! (모의 구현)");
    setTitle("");
    setContent("");
    setFile(null);
  };

  const handleVote = (postId) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId ? { ...p, votes: p.votes + 1 } : p
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">심야당 자유게시판</h1>

      <Card className="bg-gray-900 border-gray-700 mb-6">
        <CardContent className="space-y-4 p-4">
          <Input
            placeholder="제목을 입력하세요"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white"
          />
          <Textarea
            placeholder="내용을 입력하세요"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white min-h-[150px]"
          />
          <div className="flex items-center space-x-4">
            <Input
              type="file"
              onChange={(e) => setFile(e.target.files[0])}
              className="text-white"
            />
            <Button onClick={handleUpload} className="bg-blue-600 hover:bg-blue-700">
              <UploadCloud className="mr-2 h-4 w-4" /> 업로드
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {posts
          .sort((a, b) => (b.isNotice ? 1 : 0) - (a.isNotice ? 1 : 0))
          .map((post) => (
            <motion.div
              key={post.id}
              className={`bg-gray-900 border border-gray-700 p-4 rounded-xl ${post.isNotice ? "border-yellow-400" : ""}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h2 className="text-xl font-semibold">{post.title}</h2>
              <p className="text-sm text-gray-300 mt-2">{post.content}</p>
              {post.fileName && (
                <p className="text-xs mt-2 text-gray-400">파일: {post.fileName}</p>
              )}
              <div className="flex items-center gap-4 mt-2">
                <Button
                  className="text-xs bg-purple-700 hover:bg-purple-800"
                  onClick={() => handleVote(post.id)}
                >
                  👍 추천 ({post.votes})
                </Button>
                {post.isNotice && <span className="text-yellow-400 text-xs">📌 공지</span>}
              </div>
            </motion.div>
          ))}
      </div>
    </div>
  );
}
